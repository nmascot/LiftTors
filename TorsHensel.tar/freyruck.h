#include <pari/pari.h>

GEN FindSuppl(GEN V, GEN W, GEN T, GEN p, GEN pe, GEN V3, ulong nV5);
GEN detratio(GEN K, GEN T, GEN p, long e, GEN pe);
GEN PicNorm(GEN J, GEN F, GEN WE);
GEN PicFreyRuckMulti(GEN J, GEN Wtors, GEN l, GEN Wtest, GEN W0, GEN C);
GEN PicTorsRels(GEN J, GEN Wtors, GEN l, ulong excess);
