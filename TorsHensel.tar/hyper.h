GEN HyperRandPt(GEN f, GEN T, GEN p, ulong e, GEN pe);
GEN RReval(GEN Ps, ulong n, ulong d, GEN T, GEN pe);
GEN HyperInit(GEN f, GEN p, ulong a, long e);
GEN HyperPicRand(GEN J,GEN f);
GEN ordJ(GEN f, GEN p, ulong a);
GEN HyperPicRandTors(GEN J, GEN f, GEN l, GEN C);
GEN HyperPicEvalData(GEN J);
GEN HyperPicEval(GEN J, GEN W, GEN U);
