#include<pari/pari.h>

GEN AddChain(GEN n, long signmatters);
